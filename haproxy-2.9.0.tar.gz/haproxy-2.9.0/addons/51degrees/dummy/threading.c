typedef struct fiftyoneDegrees_threading_t {
    // This is an empty structure to ensure a threading.o is generated
    // by the dummy library, it is never used.
} dummyFiftyoneDegreesThreading;