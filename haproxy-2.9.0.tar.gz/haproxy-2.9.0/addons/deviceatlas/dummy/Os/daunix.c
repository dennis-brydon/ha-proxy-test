#include "dac.h"

static char const __attribute__((unused)) rcsid[] = "$Id: dac.c, v dummy 1970/01/01 00:00:01 dcarlier Exp $";

da_status_t
da_atlas_read_mapped(const char *path, void *m, void **p, size_t *l)
{
    return DA_SYS;
}
